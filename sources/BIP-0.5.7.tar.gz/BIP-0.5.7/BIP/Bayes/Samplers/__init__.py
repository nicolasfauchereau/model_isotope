__author__="fccoelho"
__date__ ="$09/12/2009 10:41:15$"
from BIP import logsetup

